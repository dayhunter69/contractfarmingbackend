// flockDetailController.js
import db from '../config/database.js';

export const createFlockDetail = (req, res) => {
  console.log('Received form data:', req.body);
  console.log('Received file:', req.file);

  const {
    nepali_date,
    english_date,
    location,
    age_days,
    num_birds,
    mortality_birds,
    bps_stock,
    b1_stock,
    b2_stock,
    bps_consumption,
    b1_consumption,
    b2_consumption,
    mortality_reason,
    medicine,
    flock_id,
  } = req.body;

  const image_mortality = req.file ? req.file.path : null;

  const query = `INSERT INTO flock_detail 
                 (nepali_date, english_date, location, age_days, num_birds, mortality_birds, 
                  bps_stock, b1_stock, b2_stock, bps_consumption, b1_consumption, b2_consumption, 
                  mortality_reason, medicine, image_mortality, flock_id)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;

  db.query(
    query,
    [
      nepali_date,
      english_date,
      location,
      age_days,
      num_birds,
      mortality_birds,
      bps_stock,
      b1_stock,
      b2_stock,
      bps_consumption,
      b1_consumption,
      b2_consumption,
      mortality_reason,
      medicine,
      image_mortality,
      flock_id,
    ],
    (err, result) => {
      if (err) {
        console.error('Database error:', err);
        res.status(500).send({ message: err.message });
      } else {
        res.status(201).send({
          message: 'Flock detail created successfully',
          flockDetailId: result.insertId,
        });
      }
    }
  );
};

export const getFlockDetails = (req, res) => {
  const query = 'SELECT * FROM flock_detail';

  db.query(query, (err, results) => {
    if (err) {
      res.status(500).send({ message: err.message });
    } else {
      res.status(200).send(results);
    }
  });
};

export const getFlockDetailById = (req, res) => {
  const flock_id = req.params.id;

  const query = 'SELECT * FROM flock_detail WHERE flock_id = ?';

  db.query(query, [flock_id], (err, results) => {
    if (err) {
      res.status(500).send({ message: err.message });
    } else if (results.length === 0) {
      res.status(404).send({ message: 'Flock details not found' });
    } else {
      res.status(200).send(results);
    }
  });
};
